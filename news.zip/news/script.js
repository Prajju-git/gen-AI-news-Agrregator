function explore() {
  alert("Welcome to GenAI News Hub! Smart news will be available soon.");
}
